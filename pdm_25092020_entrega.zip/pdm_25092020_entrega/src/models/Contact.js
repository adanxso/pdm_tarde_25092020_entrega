class Contact {
  constructor({ id, name, phone, image }) {
    this.id = id
    this.name = name
    this.phone = phone
    this.image = image
  }
}

export default Contact
